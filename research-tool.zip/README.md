# Research Tool - Earnings Call Analyzer

## Features
- Upload earnings call transcript
- AI analyzes transcript
- Provides structured financial summary

## Tech Stack
- Streamlit
- OpenAI API
- Python

## Deployment
Deploy easily on Streamlit Cloud.
